package br.ulbra.appbuguer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class cadastro extends AppCompatActivity {
    DBHelper db;
        Button btnCadastro_cad;
        EditText edtNome_cad,edtEmail_cad,edtPass_cad,edtTelefone_cad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro);
        edtNome_cad = findViewById(R.id.edtNome_cad);
        edtEmail_cad = findViewById(R.id.edtEmail_cad);
        edtTelefone_cad = findViewById(R.id.edtTelefone_cad);
        edtPass_cad = findViewById(R.id.edtPass_cad);
        db = new DBHelper(this);
        btnCadastro_cad = findViewById(R.id.btnCadastro_cad);
        btnCadastro_cad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edtEmail_cad.getText().toString();
                String userName = edtNome_cad.getText().toString();
                String pas1 = edtPass_cad.getText().toString();
                Double tel = Double.parseDouble(edtTelefone_cad.getText().toString());

                if(userName.equals("")){
                    Toast.makeText(cadastro.this, "Insira o nome do usuário", Toast.LENGTH_SHORT).show();
                }
                else if (email.equals("")) {
                    Toast.makeText(cadastro.this, "Insira o EMAIL DO USUÁRIO", Toast.LENGTH_LONG).show();
                } else if (pas1.equals("") || tel.equals("")) {
                    Toast.makeText(cadastro.this, "Insira a SENHA DO USUÁRIO", Toast.LENGTH_LONG).show();
                } else if (tel == null) {
                    Toast.makeText(cadastro.this, "Insira o TELEFONE DO USUÁRIO", Toast.LENGTH_LONG).show();
                } else {
                    long res = db.criarUtilizador(userName, pas1);
                    if (res > 0) {
                        Toast.makeText(cadastro.this, "Resgistro OK", Toast.LENGTH_LONG).show();
                        Intent i = new Intent(cadastro.this, MainActivity.class);
                        startActivity(i);
                    }

                }
            }
        });
        };
    }
