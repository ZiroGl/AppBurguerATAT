package br.ulbra.appbuguer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class catalogo extends AppCompatActivity {
    Button btnVoltar_catalogo;
    ImageButton whats;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_catalogo1);
        btnVoltar_catalogo = findViewById(R.id.btnVoltar_catalogo);
        whats = findViewById(R.id.whats);
        btnVoltar_catalogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(catalogo.this,cadastro.class);
                startActivity(i);
            }
        });
        whats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://web.whatsapp.com/");
                Intent ti = new Intent(Intent.ACTION_VIEW,uri);
                startActivity(ti);
            }
        });
     }
}