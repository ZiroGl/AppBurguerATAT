package br.ulbra.appbuguer;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperProd extends SQLiteOpenHelper {
    private static String nome = "BancoDados.db";
    private static int versao=1;

    public DBHelperProd(Context context){
        super(context, nome,null,versao);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String str = "CREATE TABLE produtos(PKidprod int PRIMARY KEY, nomeprod TEXT , precoprod TEXT);";
        db.execSQL(str);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS produtos;");
        onCreate(db);

    }
    public long criarProd(String nomeprod, String precoprod){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("O LENDARIO",nomeprod);
        cv.put("R$ 40,00",precoprod);
        cv.put("O INCRIVEL",nomeprod);
        cv.put("R$ 30,00",precoprod);
        cv.put("O MAXIMO",nomeprod);
        cv.put("R$ 40,00",precoprod);


        long result = db.insert("produtos", null,cv);

        return result;
    }
}
