package br.ulbra.appbuguer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edtLogin_main,edtPass_main;
    DBHelper db;
    Button btnLogin_main,btnRegistrar_main;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edtLogin_main = findViewById(R.id.edtLogin_main);
        edtPass_main = findViewById(R.id.edtPass_main);
        btnLogin_main = findViewById(R.id.btnLogin_main);
        btnRegistrar_main = findViewById(R.id.btnRegistrar_main);
        db = new DBHelper(this);
        btnLogin_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    String username = edtLogin_main.getText().toString();
                    String password = edtPass_main.getText().toString();

                    if (username.equals("")) {
                        Toast.makeText(MainActivity.this, "Usuario não inserido, tente novamente", Toast.LENGTH_SHORT).show();
                    } else if (password.equals("")) {
                        Toast.makeText(MainActivity.this, "Senha não inserida, tente novamente", Toast.LENGTH_SHORT).show();
                    } else {
                        String res = db.validarLogin(username, password);
                        if (res.equals("OK")) {
                            Toast.makeText(MainActivity.this, "Login OK !!", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(MainActivity.this,  catalogo.class);
                            startActivity(i);
                        } else {
                            Toast.makeText(MainActivity.this, "Login ou Senha errado(s)!!", Toast.LENGTH_SHORT).show();
                        }

                    };
                }catch (Exception e){}
            }


        });
        btnRegistrar_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,cadastro.class);
                startActivity(i);
            }
        });

        };


    }
